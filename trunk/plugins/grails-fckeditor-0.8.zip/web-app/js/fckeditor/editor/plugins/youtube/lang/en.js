/*
 * For FCKeditor 2.3
 * 
 * 
 * File Name: ja.js
 * 	English language file for the youtube plugin.
 * 
 * File Authors:
 * 		Uprush (uprushworld@yahoo.co.jp) 2007/10/30
 */

FCKLang['YouTubeTip']			= 'Insert/Edit YouTube' ;
FCKLang['DlgYouTubeTitle']		= 'YouTube Property' ;
FCKLang['DlgYouTubeHelp']		= 'Paste the HTML snippet of YouTube videos here.' ;
FCKLang['DlgYouTubeCode']		= 'HTML snippet' ;
FCKLang['DlgAlertYouTubeCode']	= 'Please insert the the HTML snippet of YouTube videos.' ;
FCKLang['DlgAlertYouTubeSecurity']	= 'Invalid HTML snippet.' ;