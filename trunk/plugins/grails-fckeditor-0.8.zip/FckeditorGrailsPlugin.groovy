class FckeditorGrailsPlugin {
    def version = '0.8'
    def dependsOn = [:]
	
    def author = "Stefano Gualdi"
    def authorEmail = "stefano.gualdi@gmail.com"
    def title = "Fckeditor"
    def description = 'Native Grails plugin for using FCKeditor rich editing features in a Grails application'
    def documentation = "http://grails.org/FCKeditor+plugin"
	
    def doWithSpring = {
    }
   
    def doWithApplicationContext = { applicationContext ->
    }

    def doWithWebDescriptor = { xml ->
    }
	                                      
    def doWithDynamicMethods = { ctx ->
    }
	
    def onChange = { event ->
    }
                                                                                  
    def onApplicationChange = { event ->
    }
}
