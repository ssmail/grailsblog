class FckeditorUrlMappings {
    static mappings = {
    	"/fckconnector" ( controller: "fckeditor", action: "connector" )
    	"/fckuploader" ( controller: "fckeditor", action: "uploader" )
    }
}